import { Id } from "../../convex/_generated/dataModel";

interface Podcast {
  _id: Id<"podcasts">;
  title: string;
  description: string;
  category: string;
  coverImageUrl: string | null;
  totalEpisodes: number;
}

interface PodcastGridProps {
  podcasts: Podcast[];
  onPodcastSelect: (podcastId: Id<"podcasts">) => void;
}

export function PodcastGrid({ podcasts, onPodcastSelect }: PodcastGridProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {podcasts.map((podcast) => (
        <div
          key={podcast._id}
          onClick={() => onPodcastSelect(podcast._id)}
          className="group cursor-pointer bg-white rounded-2xl p-6 shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100 hover:border-purple-200 transform hover:-translate-y-1"
        >
          <div className="aspect-square bg-gradient-to-br from-purple-100 to-pink-100 rounded-xl mb-4 flex items-center justify-center overflow-hidden">
            {podcast.coverImageUrl ? (
              <img
                src={podcast.coverImageUrl}
                alt={podcast.title}
                className="w-full h-full object-cover"
              />
            ) : (
              <svg className="w-12 h-12 text-purple-400" fill="currentColor" viewBox="0 0 20 20">
                <path d="M18 3a1 1 0 00-1.196-.98l-10 2A1 1 0 006 5v9.114A4.369 4.369 0 005 14c-1.657 0-3 .895-3 2s1.343 2 3 2 3-.895 3-2V7.82l8-1.6v5.894A4.37 4.37 0 0015 12c-1.657 0-3 .895-3 2s1.343 2 3 2 3-.895 3-2V3z"/>
              </svg>
            )}
          </div>
          
          <h3 className="font-semibold text-gray-900 mb-2 group-hover:text-purple-600 transition-colors line-clamp-2">
            {podcast.title}
          </h3>
          
          <p className="text-gray-600 text-sm mb-3 line-clamp-2">
            {podcast.description}
          </p>
          
          <div className="flex justify-between items-center text-xs">
            <span className="bg-purple-100 text-purple-700 px-2 py-1 rounded-full font-medium">
              {podcast.category}
            </span>
            <span className="text-gray-500">
              {podcast.totalEpisodes} episodes
            </span>
          </div>
        </div>
      ))}
    </div>
  );
}
