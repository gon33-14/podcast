import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { PodcastGrid } from "./PodcastGrid";
import { CreatePodcastModal } from "./CreatePodcastModal";
import { PodcastDetail } from "./PodcastDetail";
import { ConversationView } from "./ConversationView";
import { Id } from "../../convex/_generated/dataModel";

type View = "dashboard" | "podcast" | "conversation";

export function PodcastDashboard() {
  const [currentView, setCurrentView] = useState<View>("dashboard");
  const [selectedPodcastId, setSelectedPodcastId] = useState<Id<"podcasts"> | null>(null);
  const [selectedConversationId, setSelectedConversationId] = useState<Id<"conversations"> | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);

  const userPodcasts = useQuery(api.podcasts.getUserPodcasts);
  const publicPodcasts = useQuery(api.podcasts.getPublicPodcasts, {});

  const handlePodcastSelect = (podcastId: Id<"podcasts">) => {
    setSelectedPodcastId(podcastId);
    setCurrentView("podcast");
  };

  const handleConversationStart = (conversationId: Id<"conversations">) => {
    setSelectedConversationId(conversationId);
    setCurrentView("conversation");
  };

  const handleBackToDashboard = () => {
    setCurrentView("dashboard");
    setSelectedPodcastId(null);
    setSelectedConversationId(null);
  };

  if (currentView === "conversation" && selectedConversationId) {
    return (
      <ConversationView
        conversationId={selectedConversationId}
        onBack={handleBackToDashboard}
      />
    );
  }

  if (currentView === "podcast" && selectedPodcastId) {
    return (
      <PodcastDetail
        podcastId={selectedPodcastId}
        onBack={handleBackToDashboard}
        onStartConversation={handleConversationStart}
      />
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Your Podcasts</h2>
          <p className="text-gray-600 mt-1">Create, manage, and chat with your AI-powered podcasts</p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-3 rounded-xl font-semibold hover:from-purple-600 hover:to-pink-600 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
        >
          Create Podcast
        </button>
      </div>

      {/* User Podcasts */}
      {userPodcasts && userPodcasts.length > 0 && (
        <div>
          <h3 className="text-xl font-semibold text-gray-800 mb-4">My Podcasts</h3>
          <PodcastGrid podcasts={userPodcasts} onPodcastSelect={handlePodcastSelect} />
        </div>
      )}

      {/* Public Podcasts */}
      {publicPodcasts && publicPodcasts.length > 0 && (
        <div>
          <h3 className="text-xl font-semibold text-gray-800 mb-4">Discover Podcasts</h3>
          <PodcastGrid podcasts={publicPodcasts} onPodcastSelect={handlePodcastSelect} />
        </div>
      )}

      {/* Empty State */}
      {userPodcasts?.length === 0 && publicPodcasts?.length === 0 && (
        <div className="text-center py-20">
          <div className="w-24 h-24 bg-gradient-to-br from-purple-100 to-pink-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg className="w-12 h-12 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
            </svg>
          </div>
          <h3 className="text-2xl font-semibold text-gray-900 mb-2">No podcasts yet</h3>
          <p className="text-gray-600 mb-6">Create your first AI-powered podcast to get started</p>
          <button
            onClick={() => setShowCreateModal(true)}
            className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-8 py-3 rounded-xl font-semibold hover:from-purple-600 hover:to-pink-600 transition-all duration-200"
          >
            Create Your First Podcast
          </button>
        </div>
      )}

      {/* Create Podcast Modal */}
      {showCreateModal && (
        <CreatePodcastModal onClose={() => setShowCreateModal(false)} />
      )}
    </div>
  );
}
