import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { toast } from "sonner";

interface PodcastDetailProps {
  podcastId: Id<"podcasts">;
  onBack: () => void;
  onStartConversation: (conversationId: Id<"conversations">) => void;
}

export function PodcastDetail({ podcastId, onBack, onStartConversation }: PodcastDetailProps) {
  const [showCreateEpisode, setShowCreateEpisode] = useState(false);
  const [episodeForm, setEpisodeForm] = useState({
    title: "",
    description: "",
    generationPrompt: "",
  });

  const podcast = useQuery(api.podcasts.getPodcastById, { podcastId });
  const episodes = useQuery(api.episodes.getPodcastEpisodes, { podcastId });
  const createEpisode = useMutation(api.episodes.createEpisode);
  const startConversation = useMutation(api.conversations.startConversation);

  const handleCreateEpisode = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!episodeForm.title || !episodeForm.description) {
      toast.error("Please fill in all required fields");
      return;
    }

    try {
      await createEpisode({
        podcastId,
        ...episodeForm,
      });
      toast.success("Episode created successfully!");
      setShowCreateEpisode(false);
      setEpisodeForm({ title: "", description: "", generationPrompt: "" });
    } catch (error) {
      toast.error("Failed to create episode");
    }
  };

  const handleStartConversation = async () => {
    try {
      const conversationId = await startConversation({ podcastId });
      onStartConversation(conversationId);
    } catch (error) {
      toast.error("Failed to start conversation");
    }
  };

  if (!podcast) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="w-12 h-12 border-4 border-purple-200 border-t-purple-500 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center mb-8">
        <button
          onClick={onBack}
          className="mr-4 p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <svg className="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        <h1 className="text-3xl font-bold text-gray-900">Podcast Details</h1>
      </div>

      {/* Podcast Info */}
      <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100 mb-8">
        <div className="flex flex-col md:flex-row gap-8">
          <div className="w-48 h-48 bg-gradient-to-br from-purple-100 to-pink-100 rounded-2xl flex items-center justify-center flex-shrink-0">
            {podcast.coverImageUrl ? (
              <img
                src={podcast.coverImageUrl}
                alt={podcast.title}
                className="w-full h-full object-cover rounded-2xl"
              />
            ) : (
              <svg className="w-20 h-20 text-purple-400" fill="currentColor" viewBox="0 0 20 20">
                <path d="M18 3a1 1 0 00-1.196-.98l-10 2A1 1 0 006 5v9.114A4.369 4.369 0 005 14c-1.657 0-3 .895-3 2s1.343 2 3 2 3-.895 3-2V7.82l8-1.6v5.894A4.37 4.37 0 0015 12c-1.657 0-3 .895-3 2s1.343 2 3 2 3-.895 3-2V3z"/>
              </svg>
            )}
          </div>
          
          <div className="flex-1">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">{podcast.title}</h2>
            <p className="text-gray-600 mb-4">{podcast.description}</p>
            
            <div className="flex flex-wrap gap-4 mb-6">
              <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-medium">
                {podcast.category}
              </span>
              <span className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm">
                {podcast.totalEpisodes} episodes
              </span>
            </div>

            <div className="flex flex-wrap gap-3">
              <button
                onClick={handleStartConversation}
                className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-3 rounded-xl font-semibold hover:from-purple-600 hover:to-pink-600 transition-all duration-200 shadow-lg hover:shadow-xl"
              >
                Chat with AI Host
              </button>
              <button
                onClick={() => setShowCreateEpisode(true)}
                className="bg-white border border-gray-200 text-gray-700 px-6 py-3 rounded-xl font-semibold hover:bg-gray-50 transition-colors"
              >
                Create Episode
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Episodes */}
      <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">Episodes</h3>
        
        {episodes && episodes.length > 0 ? (
          <div className="space-y-4">
            {episodes.map((episode) => (
              <div
                key={episode._id}
                className="border border-gray-200 rounded-xl p-6 hover:border-purple-200 transition-colors"
              >
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-semibold text-gray-900">
                    Episode {episode.episodeNumber}: {episode.title}
                  </h4>
                  {episode.isGenerated && (
                    <span className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs font-medium">
                      AI Generated
                    </span>
                  )}
                </div>
                <p className="text-gray-600 mb-4">{episode.description}</p>
                {episode.transcript && (
                  <div className="bg-gray-50 rounded-lg p-4">
                    <p className="text-sm text-gray-700">{episode.transcript}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <svg className="w-16 h-16 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
            </svg>
            <h4 className="text-lg font-medium text-gray-900 mb-2">No episodes yet</h4>
            <p className="text-gray-600 mb-4">Create your first episode to get started</p>
            <button
              onClick={() => setShowCreateEpisode(true)}
              className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-3 rounded-xl font-semibold hover:from-purple-600 hover:to-pink-600 transition-all duration-200"
            >
              Create First Episode
            </button>
          </div>
        )}
      </div>

      {/* Create Episode Modal */}
      {showCreateEpisode && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-gray-900">Create New Episode</h3>
                <button
                  onClick={() => setShowCreateEpisode(false)}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>

              <form onSubmit={handleCreateEpisode} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Episode Title *
                  </label>
                  <input
                    type="text"
                    value={episodeForm.title}
                    onChange={(e) => setEpisodeForm({ ...episodeForm, title: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                    placeholder="Enter episode title"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Description *
                  </label>
                  <textarea
                    value={episodeForm.description}
                    onChange={(e) => setEpisodeForm({ ...episodeForm, description: e.target.value })}
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all resize-none"
                    placeholder="Describe the episode"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    AI Generation Prompt (Optional)
                  </label>
                  <textarea
                    value={episodeForm.generationPrompt}
                    onChange={(e) => setEpisodeForm({ ...episodeForm, generationPrompt: e.target.value })}
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all resize-none"
                    placeholder="Tell the AI what to talk about in this episode"
                  />
                </div>

                <div className="flex space-x-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setShowCreateEpisode(false)}
                    className="flex-1 px-4 py-3 border border-gray-200 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors font-medium"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 px-4 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl hover:from-purple-600 hover:to-pink-600 transition-all font-medium"
                  >
                    Create Episode
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
