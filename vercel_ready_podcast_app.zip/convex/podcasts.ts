import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const createPodcast = mutation({
  args: {
    title: v.string(),
    description: v.string(),
    category: v.string(),
    aiPersonality: v.string(),
    isPublic: v.boolean(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    return await ctx.db.insert("podcasts", {
      ...args,
      creatorId: userId,
      totalEpisodes: 0,
    });
  },
});

export const getUserPodcasts = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const podcasts = await ctx.db
      .query("podcasts")
      .withIndex("by_creator", (q) => q.eq("creatorId", userId))
      .collect();

    return Promise.all(
      podcasts.map(async (podcast) => ({
        ...podcast,
        coverImageUrl: podcast.coverImageId
          ? await ctx.storage.getUrl(podcast.coverImageId)
          : null,
      }))
    );
  },
});

export const getPublicPodcasts = query({
  args: { category: v.optional(v.string()) },
  handler: async (ctx, args) => {
    let podcasts;
    
    if (args.category) {
      podcasts = await ctx.db
        .query("podcasts")
        .withIndex("by_category", (q) => q.eq("category", args.category as string))
        .filter((q) => q.eq(q.field("isPublic"), true))
        .collect();
    } else {
      podcasts = await ctx.db
        .query("podcasts")
        .filter((q) => q.eq(q.field("isPublic"), true))
        .collect();
    }



    return Promise.all(
      podcasts.map(async (podcast) => ({
        ...podcast,
        coverImageUrl: podcast.coverImageId
          ? await ctx.storage.getUrl(podcast.coverImageId)
          : null,
      }))
    );
  },
});

export const getPodcastById = query({
  args: { podcastId: v.id("podcasts") },
  handler: async (ctx, args) => {
    const podcast = await ctx.db.get(args.podcastId);
    if (!podcast) return null;

    return {
      ...podcast,
      coverImageUrl: podcast.coverImageId
        ? await ctx.storage.getUrl(podcast.coverImageId)
        : null,
    };
  },
});

export const searchPodcasts = query({
  args: { searchTerm: v.string(), category: v.optional(v.string()) },
  handler: async (ctx, args) => {
    const results = await ctx.db
      .query("podcasts")
      .withSearchIndex("search_podcasts", (q) => {
        let search = q.search("title", args.searchTerm);
        if (args.category) {
          search = search.eq("category", args.category);
        }
        return search.eq("isPublic", true);
      })
      .take(20);

    return Promise.all(
      results.map(async (podcast) => ({
        ...podcast,
        coverImageUrl: podcast.coverImageId
          ? await ctx.storage.getUrl(podcast.coverImageId)
          : null,
      }))
    );
  },
});

export const generateUploadUrl = mutation({
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});

export const updatePodcastCover = mutation({
  args: {
    podcastId: v.id("podcasts"),
    coverImageId: v.id("_storage"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const podcast = await ctx.db.get(args.podcastId);
    if (!podcast || podcast.creatorId !== userId) {
      throw new Error("Not authorized");
    }

    await ctx.db.patch(args.podcastId, {
      coverImageId: args.coverImageId,
    });
  },
});
