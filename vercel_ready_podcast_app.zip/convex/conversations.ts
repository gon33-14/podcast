import { v } from "convex/values";
import { query, mutation, action, internalQuery, internalMutation, internalAction } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { internal } from "./_generated/api";

export const startConversation = mutation({
  args: { podcastId: v.id("podcasts") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Check if there's an active conversation
    const existingConversation = await ctx.db
      .query("conversations")
      .withIndex("by_podcast_user", (q) => 
        q.eq("podcastId", args.podcastId).eq("userId", userId)
      )
      .filter((q) => q.eq(q.field("isActive"), true))
      .first();

    if (existingConversation) {
      return existingConversation._id;
    }

    return await ctx.db.insert("conversations", {
      podcastId: args.podcastId,
      userId,
      messages: [],
      isActive: true,
    });
  },
});

export const sendMessage = mutation({
  args: {
    conversationId: v.id("conversations"),
    message: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const conversation = await ctx.db.get(args.conversationId);
    if (!conversation || conversation.userId !== userId) {
      throw new Error("Not authorized");
    }

    const userMessage = {
      role: "user" as const,
      content: args.message,
      timestamp: Date.now(),
    };

    const updatedMessages = [...conversation.messages, userMessage];

    await ctx.db.patch(args.conversationId, {
      messages: updatedMessages,
    });

    // Schedule AI response
    await ctx.scheduler.runAfter(0, internal.conversations.generateAIResponse, {
      conversationId: args.conversationId,
    });

    return userMessage;
  },
});

export const generateAIResponse = internalAction({
  args: { conversationId: v.id("conversations") },
  handler: async (ctx, args) => {
    const conversation = await ctx.runQuery(internal.conversations.getConversationForAI, {
      conversationId: args.conversationId,
    });

    if (!conversation) return;

    const messages = conversation.messages.map((msg: any) => ({
      role: msg.role,
      content: msg.content,
    }));

    const response = await fetch(process.env.CONVEX_OPENAI_BASE_URL + "/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.CONVEX_OPENAI_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4.1-nano",
        messages: [
          {
            role: "system",
            content: `You are an AI podcast host with this personality: ${conversation.podcast.aiPersonality}. Engage in natural conversation about the podcast topic: ${conversation.podcast.description}. Be conversational, knowledgeable, and entertaining.`,
          },
          ...messages,
        ],
        max_tokens: 500,
      }),
    });

    const data = await response.json();
    const aiResponse = data.choices[0].message.content;

    await ctx.runMutation(internal.conversations.addAIMessage, {
      conversationId: args.conversationId,
      message: aiResponse,
    });
  },
});

export const getConversationForAI = internalQuery({
  args: { conversationId: v.id("conversations") },
  handler: async (ctx, args) => {
    const conversation = await ctx.db.get(args.conversationId);
    if (!conversation) return null;

    const podcast = await ctx.db.get(conversation.podcastId);
    if (!podcast) return null;

    return { ...conversation, podcast };
  },
});

export const addAIMessage = internalMutation({
  args: {
    conversationId: v.id("conversations"),
    message: v.string(),
  },
  handler: async (ctx, args) => {
    const conversation = await ctx.db.get(args.conversationId);
    if (!conversation) return;

    const aiMessage = {
      role: "assistant" as const,
      content: args.message,
      timestamp: Date.now(),
    };

    const updatedMessages = [...conversation.messages, aiMessage];

    await ctx.db.patch(args.conversationId, {
      messages: updatedMessages,
    });
  },
});

export const getConversation = query({
  args: { conversationId: v.id("conversations") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const conversation = await ctx.db.get(args.conversationId);
    if (!conversation || conversation.userId !== userId) {
      return null;
    }

    const podcast = await ctx.db.get(conversation.podcastId);
    return { ...conversation, podcast };
  },
});

export const getUserConversations = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const conversations = await ctx.db
      .query("conversations")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();

    return Promise.all(
      conversations.map(async (conversation) => {
        const podcast = await ctx.db.get(conversation.podcastId);
        return { ...conversation, podcast };
      })
    );
  },
});

export const endConversation = mutation({
  args: { conversationId: v.id("conversations") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const conversation = await ctx.db.get(args.conversationId);
    if (!conversation || conversation.userId !== userId) {
      throw new Error("Not authorized");
    }

    await ctx.db.patch(args.conversationId, {
      isActive: false,
    });
  },
});
