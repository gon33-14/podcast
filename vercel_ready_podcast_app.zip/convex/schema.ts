import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  podcasts: defineTable({
    title: v.string(),
    description: v.string(),
    coverImageId: v.optional(v.id("_storage")),
    creatorId: v.id("users"),
    category: v.string(),
    isPublic: v.boolean(),
    aiPersonality: v.string(),
    totalEpisodes: v.number(),
  })
    .index("by_creator", ["creatorId"])
    .index("by_category", ["category"])
    .searchIndex("search_podcasts", {
      searchField: "title",
      filterFields: ["category", "isPublic"],
    }),

  episodes: defineTable({
    podcastId: v.id("podcasts"),
    title: v.string(),
    description: v.string(),
    audioFileId: v.optional(v.id("_storage")),
    transcript: v.optional(v.string()),
    duration: v.optional(v.number()),
    episodeNumber: v.number(),
    isGenerated: v.boolean(),
    generationPrompt: v.optional(v.string()),
  })
    .index("by_podcast", ["podcastId"])
    .index("by_podcast_episode", ["podcastId", "episodeNumber"]),

  conversations: defineTable({
    podcastId: v.id("podcasts"),
    userId: v.id("users"),
    messages: v.array(v.object({
      role: v.union(v.literal("user"), v.literal("assistant")),
      content: v.string(),
      timestamp: v.number(),
    })),
    isActive: v.boolean(),
  })
    .index("by_podcast_user", ["podcastId", "userId"])
    .index("by_user", ["userId"]),

  recordings: defineTable({
    conversationId: v.id("conversations"),
    audioFileId: v.id("_storage"),
    duration: v.number(),
    transcript: v.optional(v.string()),
  })
    .index("by_conversation", ["conversationId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
