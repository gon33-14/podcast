import { v } from "convex/values";
import { query, mutation, action, internalQuery, internalMutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { internal } from "./_generated/api";

export const getPodcastEpisodes = query({
  args: { podcastId: v.id("podcasts") },
  handler: async (ctx, args) => {
    const episodes = await ctx.db
      .query("episodes")
      .withIndex("by_podcast", (q) => q.eq("podcastId", args.podcastId))
      .order("desc")
      .collect();

    return Promise.all(
      episodes.map(async (episode) => ({
        ...episode,
        audioUrl: episode.audioFileId
          ? await ctx.storage.getUrl(episode.audioFileId)
          : null,
      }))
    );
  },
});

export const createEpisode = mutation({
  args: {
    podcastId: v.id("podcasts"),
    title: v.string(),
    description: v.string(),
    generationPrompt: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const podcast = await ctx.db.get(args.podcastId);
    if (!podcast || podcast.creatorId !== userId) {
      throw new Error("Not authorized");
    }

    const episodeNumber = podcast.totalEpisodes + 1;

    const episodeId = await ctx.db.insert("episodes", {
      ...args,
      episodeNumber,
      isGenerated: !!args.generationPrompt,
    });

    await ctx.db.patch(args.podcastId, {
      totalEpisodes: episodeNumber,
    });

    return episodeId;
  },
});

export const generateEpisodeContent = action({
  args: {
    episodeId: v.id("episodes"),
    prompt: v.string(),
  },
  handler: async (ctx, args): Promise<string> => {
    const episode: any = await ctx.runQuery(internal.episodes.getEpisodeForGeneration, {
      episodeId: args.episodeId,
    });

    if (!episode) throw new Error("Episode not found");

    // Generate content using OpenAI
    const response: any = await fetch(process.env.CONVEX_OPENAI_BASE_URL + "/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.CONVEX_OPENAI_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4.1-nano",
        messages: [
          {
            role: "system",
            content: `You are an AI podcast host with this personality: ${episode.podcast.aiPersonality}. Create engaging podcast content based on the user's prompt. Make it conversational, informative, and entertaining.`,
          },
          {
            role: "user",
            content: args.prompt,
          },
        ],
        max_tokens: 2000,
      }),
    });

    const data: any = await response.json();
    const content: string = data.choices[0].message.content;

    await ctx.runMutation(internal.episodes.updateEpisodeContent, {
      episodeId: args.episodeId,
      transcript: content,
    });

    return content;
  },
});

export const getEpisodeForGeneration = internalQuery({
  args: { episodeId: v.id("episodes") },
  handler: async (ctx, args) => {
    const episode = await ctx.db.get(args.episodeId);
    if (!episode) return null;

    const podcast = await ctx.db.get(episode.podcastId);
    if (!podcast) return null;

    return { ...episode, podcast };
  },
});

export const updateEpisodeContent = internalMutation({
  args: {
    episodeId: v.id("episodes"),
    transcript: v.string(),
  },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.episodeId, {
      transcript: args.transcript,
    });
  },
});
